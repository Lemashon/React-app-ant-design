import AppRoutes from "../Routes";
function PageContent() {
  return (
    <div className="pageContent">
      <AppRoutes />
    </div>
  );
}
export default PageContent;
