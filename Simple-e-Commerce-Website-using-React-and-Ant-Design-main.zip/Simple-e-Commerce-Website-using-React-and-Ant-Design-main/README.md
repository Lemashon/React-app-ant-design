# Simple-e-Commerce-Website-using-React-and-Ant-Design
This repo contains code base regarding youtube tutorial (https://youtu.be/maTYhCuHEGw) on how to create a simple e-commerce website using Ant Design in React JS app.

The main features includes:
- App Header with Menu and view cart button 
- App Footer with static links
- App routing using react-router-dom
- API integration to fetch data from server
- Show list of cards/e-commerce products with their details/actions

